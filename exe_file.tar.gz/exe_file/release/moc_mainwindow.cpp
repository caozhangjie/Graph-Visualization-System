/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../Desktop/big_homework/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[53];
    char stringdata0[1355];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 7), // "setMain"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 1), // "x"
QT_MOC_LITERAL(4, 22, 1), // "y"
QT_MOC_LITERAL(5, 24, 15), // "moveHonrizantly"
QT_MOC_LITERAL(6, 40, 12), // "moveVerticly"
QT_MOC_LITERAL(7, 53, 12), // "changeLayout"
QT_MOC_LITERAL(8, 66, 10), // "changeData"
QT_MOC_LITERAL(9, 77, 15), // "changeDataStart"
QT_MOC_LITERAL(10, 93, 27), // "on_actionCircular_triggered"
QT_MOC_LITERAL(11, 121, 24), // "on_actionForce_triggered"
QT_MOC_LITERAL(12, 146, 24), // "on_actionPaper_triggered"
QT_MOC_LITERAL(13, 171, 24), // "on_actionTopic_triggered"
QT_MOC_LITERAL(14, 196, 25), // "on_actionFilter_triggered"
QT_MOC_LITERAL(15, 222, 31), // "on_actionPass_through_triggered"
QT_MOC_LITERAL(16, 254, 26), // "on_actionFast_2D_triggered"
QT_MOC_LITERAL(17, 281, 25), // "on_actionRandom_triggered"
QT_MOC_LITERAL(18, 307, 28), // "on_actionSimple_2D_triggered"
QT_MOC_LITERAL(19, 336, 32), // "on_actionClustering_2D_triggered"
QT_MOC_LITERAL(20, 369, 23), // "on_actionCone_triggered"
QT_MOC_LITERAL(21, 393, 31), // "on_actionCommunity_2D_triggered"
QT_MOC_LITERAL(22, 425, 23), // "on_actionSave_triggered"
QT_MOC_LITERAL(23, 449, 30), // "on_actionLoad_layout_triggered"
QT_MOC_LITERAL(24, 480, 35), // "on_horizontalScrollBar_valueC..."
QT_MOC_LITERAL(25, 516, 5), // "value"
QT_MOC_LITERAL(26, 522, 33), // "on_verticalScrollBar_valueCha..."
QT_MOC_LITERAL(27, 556, 24), // "on_actionStart_triggered"
QT_MOC_LITERAL(28, 581, 31), // "on_node_out_slider_valueChanged"
QT_MOC_LITERAL(29, 613, 30), // "on_node_in_slider_valueChanged"
QT_MOC_LITERAL(30, 644, 31), // "on_node_sum_slider_valueChanged"
QT_MOC_LITERAL(31, 676, 29), // "on_weight_slider_valueChanged"
QT_MOC_LITERAL(32, 706, 25), // "on_actionSearch_triggered"
QT_MOC_LITERAL(33, 732, 20), // "on_start_btn_clicked"
QT_MOC_LITERAL(34, 753, 32), // "on_actionEdge_bundling_triggered"
QT_MOC_LITERAL(35, 786, 34), // "on_actionSave_paper_node_trig..."
QT_MOC_LITERAL(36, 821, 34), // "on_actionSave_paper_edge_trig..."
QT_MOC_LITERAL(37, 856, 34), // "on_actionSave_topic_node_trig..."
QT_MOC_LITERAL(38, 891, 34), // "on_actionSave_topic_edge_trig..."
QT_MOC_LITERAL(39, 926, 37), // "on_actionSave_document_node_t..."
QT_MOC_LITERAL(40, 964, 34), // "on_actionLoad_paper_node_trig..."
QT_MOC_LITERAL(41, 999, 34), // "on_actionLoad_paper_edge_trig..."
QT_MOC_LITERAL(42, 1034, 34), // "on_actionLoad_topic_node_trig..."
QT_MOC_LITERAL(43, 1069, 34), // "on_actionLoad_topic_edge_trig..."
QT_MOC_LITERAL(44, 1104, 37), // "on_actionLoad_document_node_t..."
QT_MOC_LITERAL(45, 1142, 24), // "on_actionReset_triggered"
QT_MOC_LITERAL(46, 1167, 44), // "on_actionInteraction_edge_bun..."
QT_MOC_LITERAL(47, 1212, 25), // "on_toSpinBox_valueChanged"
QT_MOC_LITERAL(48, 1238, 4), // "arg1"
QT_MOC_LITERAL(49, 1243, 27), // "on_fromSpinBox_valueChanged"
QT_MOC_LITERAL(50, 1271, 26), // "on_sumSpinBox_valueChanged"
QT_MOC_LITERAL(51, 1298, 29), // "on_weightSpinBox_valueChanged"
QT_MOC_LITERAL(52, 1328, 26) // "on_actionCartoon_triggered"

    },
    "MainWindow\0setMain\0\0x\0y\0moveHonrizantly\0"
    "moveVerticly\0changeLayout\0changeData\0"
    "changeDataStart\0on_actionCircular_triggered\0"
    "on_actionForce_triggered\0"
    "on_actionPaper_triggered\0"
    "on_actionTopic_triggered\0"
    "on_actionFilter_triggered\0"
    "on_actionPass_through_triggered\0"
    "on_actionFast_2D_triggered\0"
    "on_actionRandom_triggered\0"
    "on_actionSimple_2D_triggered\0"
    "on_actionClustering_2D_triggered\0"
    "on_actionCone_triggered\0"
    "on_actionCommunity_2D_triggered\0"
    "on_actionSave_triggered\0"
    "on_actionLoad_layout_triggered\0"
    "on_horizontalScrollBar_valueChanged\0"
    "value\0on_verticalScrollBar_valueChanged\0"
    "on_actionStart_triggered\0"
    "on_node_out_slider_valueChanged\0"
    "on_node_in_slider_valueChanged\0"
    "on_node_sum_slider_valueChanged\0"
    "on_weight_slider_valueChanged\0"
    "on_actionSearch_triggered\0"
    "on_start_btn_clicked\0"
    "on_actionEdge_bundling_triggered\0"
    "on_actionSave_paper_node_triggered\0"
    "on_actionSave_paper_edge_triggered\0"
    "on_actionSave_topic_node_triggered\0"
    "on_actionSave_topic_edge_triggered\0"
    "on_actionSave_document_node_triggered\0"
    "on_actionLoad_paper_node_triggered\0"
    "on_actionLoad_paper_edge_triggered\0"
    "on_actionLoad_topic_node_triggered\0"
    "on_actionLoad_topic_edge_triggered\0"
    "on_actionLoad_document_node_triggered\0"
    "on_actionReset_triggered\0"
    "on_actionInteraction_edge_bundling_triggered\0"
    "on_toSpinBox_valueChanged\0arg1\0"
    "on_fromSpinBox_valueChanged\0"
    "on_sumSpinBox_valueChanged\0"
    "on_weightSpinBox_valueChanged\0"
    "on_actionCartoon_triggered"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      47,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    2,  249,    2, 0x08 /* Private */,
       5,    1,  254,    2, 0x08 /* Private */,
       6,    1,  257,    2, 0x08 /* Private */,
       7,    0,  260,    2, 0x08 /* Private */,
       8,    0,  261,    2, 0x08 /* Private */,
       9,    0,  262,    2, 0x08 /* Private */,
      10,    0,  263,    2, 0x08 /* Private */,
      11,    0,  264,    2, 0x08 /* Private */,
      12,    0,  265,    2, 0x08 /* Private */,
      13,    0,  266,    2, 0x08 /* Private */,
      14,    0,  267,    2, 0x08 /* Private */,
      15,    0,  268,    2, 0x08 /* Private */,
      16,    0,  269,    2, 0x08 /* Private */,
      17,    0,  270,    2, 0x08 /* Private */,
      18,    0,  271,    2, 0x08 /* Private */,
      19,    0,  272,    2, 0x08 /* Private */,
      20,    0,  273,    2, 0x08 /* Private */,
      21,    0,  274,    2, 0x08 /* Private */,
      22,    0,  275,    2, 0x08 /* Private */,
      23,    0,  276,    2, 0x08 /* Private */,
      24,    1,  277,    2, 0x08 /* Private */,
      26,    1,  280,    2, 0x08 /* Private */,
      27,    0,  283,    2, 0x08 /* Private */,
      28,    1,  284,    2, 0x08 /* Private */,
      29,    1,  287,    2, 0x08 /* Private */,
      30,    1,  290,    2, 0x08 /* Private */,
      31,    1,  293,    2, 0x08 /* Private */,
      32,    0,  296,    2, 0x08 /* Private */,
      33,    0,  297,    2, 0x08 /* Private */,
      34,    0,  298,    2, 0x08 /* Private */,
      35,    0,  299,    2, 0x08 /* Private */,
      36,    0,  300,    2, 0x08 /* Private */,
      37,    0,  301,    2, 0x08 /* Private */,
      38,    0,  302,    2, 0x08 /* Private */,
      39,    0,  303,    2, 0x08 /* Private */,
      40,    0,  304,    2, 0x08 /* Private */,
      41,    0,  305,    2, 0x08 /* Private */,
      42,    0,  306,    2, 0x08 /* Private */,
      43,    0,  307,    2, 0x08 /* Private */,
      44,    0,  308,    2, 0x08 /* Private */,
      45,    0,  309,    2, 0x08 /* Private */,
      46,    0,  310,    2, 0x08 /* Private */,
      47,    1,  311,    2, 0x08 /* Private */,
      49,    1,  314,    2, 0x08 /* Private */,
      50,    1,  317,    2, 0x08 /* Private */,
      51,    1,  320,    2, 0x08 /* Private */,
      52,    0,  323,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    3,    4,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   25,
    QMetaType::Void, QMetaType::Int,   25,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   25,
    QMetaType::Void, QMetaType::Int,   25,
    QMetaType::Void, QMetaType::Int,   25,
    QMetaType::Void, QMetaType::Int,   25,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::Double,   48,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->setMain((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 1: _t->moveHonrizantly((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->moveVerticly((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->changeLayout(); break;
        case 4: _t->changeData(); break;
        case 5: _t->changeDataStart(); break;
        case 6: _t->on_actionCircular_triggered(); break;
        case 7: _t->on_actionForce_triggered(); break;
        case 8: _t->on_actionPaper_triggered(); break;
        case 9: _t->on_actionTopic_triggered(); break;
        case 10: _t->on_actionFilter_triggered(); break;
        case 11: _t->on_actionPass_through_triggered(); break;
        case 12: _t->on_actionFast_2D_triggered(); break;
        case 13: _t->on_actionRandom_triggered(); break;
        case 14: _t->on_actionSimple_2D_triggered(); break;
        case 15: _t->on_actionClustering_2D_triggered(); break;
        case 16: _t->on_actionCone_triggered(); break;
        case 17: _t->on_actionCommunity_2D_triggered(); break;
        case 18: _t->on_actionSave_triggered(); break;
        case 19: _t->on_actionLoad_layout_triggered(); break;
        case 20: _t->on_horizontalScrollBar_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 21: _t->on_verticalScrollBar_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->on_actionStart_triggered(); break;
        case 23: _t->on_node_out_slider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 24: _t->on_node_in_slider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 25: _t->on_node_sum_slider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 26: _t->on_weight_slider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 27: _t->on_actionSearch_triggered(); break;
        case 28: _t->on_start_btn_clicked(); break;
        case 29: _t->on_actionEdge_bundling_triggered(); break;
        case 30: _t->on_actionSave_paper_node_triggered(); break;
        case 31: _t->on_actionSave_paper_edge_triggered(); break;
        case 32: _t->on_actionSave_topic_node_triggered(); break;
        case 33: _t->on_actionSave_topic_edge_triggered(); break;
        case 34: _t->on_actionSave_document_node_triggered(); break;
        case 35: _t->on_actionLoad_paper_node_triggered(); break;
        case 36: _t->on_actionLoad_paper_edge_triggered(); break;
        case 37: _t->on_actionLoad_topic_node_triggered(); break;
        case 38: _t->on_actionLoad_topic_edge_triggered(); break;
        case 39: _t->on_actionLoad_document_node_triggered(); break;
        case 40: _t->on_actionReset_triggered(); break;
        case 41: _t->on_actionInteraction_edge_bundling_triggered(); break;
        case 42: _t->on_toSpinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 43: _t->on_fromSpinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 44: _t->on_sumSpinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 45: _t->on_weightSpinBox_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 46: _t->on_actionCartoon_triggered(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 47)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 47;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 47)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 47;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
